'''
Created on Apr 13, 2016

@author: natasha.gajic
'''
BASE_URL="http://admin2.prod.iad.caspian.rax.io:50070/"
USER_NAME="natasha"
HDFS_PATH='/apps/hive/warehouse/'
#HIVE_HOST='admin1.prod.iad.caspian.rax.io'
HIVE_HOST='localhost'
#HIVE_PORT=10000
HIVE_PORT=9083
SQL_CONNECTION_FILE = 'C:\\Users\\natasha.gajic\\workspace\\archiving-quality-control\\src\\com\\rackspace\\archiving\\quality\\control\\.sqlconn'
WEB_BASE_URL='http://localhost:50111/templeton/v1/'
QUERY_URL='http://localhost:50111/templeton/v1/hive'
WEBHCAT_USERNAME='natasha'